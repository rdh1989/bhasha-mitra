"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : manager.py
Purpose     : Central AI Model Manager

Description:
    Singleton responsible for AI model lifecycle management.

Design Pattern:
    Singleton

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from threading import Lock
from typing import Any

from app.ai.model_manager.cache import ModelCache
from app.ai.model_manager.loader import ModelLoader
from app.ai.model_manager.manifest import ManifestReader
from app.ai.model_manager.registry import ModelRegistry
from app.ai.model_manager.validator import ModelValidator
from app.ai.model_manager.downloader import ModelDownloader


class ModelManager:
    """
    Singleton responsible for managing AI models.

    Responsibilities
    ----------------
    • Read model manifest
    • Validate model metadata
    • Register models
    • Load models
    • Cache loaded models
    • Unload models
    • Provide loaded models to providers

    Notes
    -----
    This is the only public entry point of the model_manager package.
    """

    _instance: "ModelManager | None" = None
    _lock = Lock()

    def __new__(cls) -> "ModelManager":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)

        return cls._instance

    def __init__(self) -> None:

        if hasattr(self, "_initialized"):
            return

        self._initialized = True

        self._registry = ModelRegistry()
        self._validator = ModelValidator()
        self._loader = ModelLoader(self._registry)
        self._cache = ModelCache()
        self._manifest = ManifestReader()
        self._downloader = ModelDownloader()

    # -------------------------------------------------------------------------
    # Initialization
    # -------------------------------------------------------------------------

    def initialize(self) -> None:
        """
        Initialize Model Manager.

        Future implementation:
            • Read manifest.json
            • Validate manifest
            • Populate ModelRegistry
        """
        pass

    # -------------------------------------------------------------------------
    # Model Operations
    # -------------------------------------------------------------------------

    def load_model(self, model_name: str) -> Any:
        """
        Load model into memory.

        Returns cached model if already loaded.
        """

        if self._cache.exists(model_name):
            return self._cache.get(model_name)

        model = self._loader.load(model_name)

        self._cache.add(model_name, model)

        return model

    def get_model(self, model_name: str) -> Any:
        """
        Return loaded model.

        Raises
        ------
        KeyError
            If model is not loaded.
        """

        return self._cache.get(model_name)

    def unload_model(self, model_name: str) -> None:
        """
        Remove model from memory.
        """

        if not self._cache.exists(model_name):
            return

        model = self._cache.get(model_name)

        self._loader.unload(model)

        self._cache.remove(model_name)

    # -------------------------------------------------------------------------
    # Query
    # -------------------------------------------------------------------------

    def is_loaded(self, model_name: str) -> bool:
        """
        Check whether model is loaded.
        """

        return self._cache.exists(model_name)

    def list_loaded_models(self) -> list[str]:
        """
        Return names of loaded models.
        """

        return self._cache.list()

    # -------------------------------------------------------------------------
    # Shutdown
    # -------------------------------------------------------------------------

    def shutdown(self) -> None:
        """
        Unload every loaded model.
        """

        for model_name in self._cache.list():
            self.unload_model(model_name)