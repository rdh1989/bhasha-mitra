"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : contracts.py
Purpose     : Video Translation Pipeline Contracts

Description:
    Request and response models used by the Video Translation Pipeline.

    These models are exchanged between the API layer and the Pipeline layer.

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ai.asr.models import ASRResult


# -----------------------------------------------------------------------------
# AI-010 : Video Translation
# -----------------------------------------------------------------------------

@dataclass(slots=True)
class VideoTranslationRequest:
    """
    Complete video translation request.

    The Backend team is responsible for:
        • Video handling
        • Audio extraction

    The AI framework receives the extracted audio file.
    """

    audio_path: Path

    target_language: str

    generate_subtitles: bool = True

    generate_dubbing: bool = False


@dataclass(slots=True)
class VideoTranslationResult:
    """
    Complete AI translation result.
    """

    translated_text: str

    subtitle_file: Path | None = None

    dubbed_audio: Path | None = None


# -----------------------------------------------------------------------------
# AI-011 : Transcript
# -----------------------------------------------------------------------------

@dataclass(slots=True)
class VideoTranscriptRequest:
    """
    Transcript generation request.

    Backend provides the extracted audio file.

    Flow
    ----
    Audio
        ↓
    ASR
        ↓
    Transcript
    """

    audio_path: Path


@dataclass(slots=True)
class VideoTranscriptResult:
    """
    Result produced by the Transcript Pipeline.
    """

    transcription: ASRResult


# -----------------------------------------------------------------------------
# AI-012 : Subtitle
# -----------------------------------------------------------------------------

@dataclass(slots=True)
class VideoSubtitleRequest:
    """
    Subtitle generation request.

    Subtitle generation operates on transcript data.
    """

    transcription: ASRResult

    output_path: Path

    subtitle_format: str = "srt"


@dataclass(slots=True)
class VideoSubtitleResult:
    """
    Subtitle generation result.
    """

    subtitle_file: Path


# -----------------------------------------------------------------------------
# AI-013 : Dubbing
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# AI-013 : Dubbing
# -----------------------------------------------------------------------------

@dataclass(slots=True)
class VideoDubbingRequest:
    """
    Dubbing request.

    Backend provides already translated text.

    Flow
    ----
    Translated Text
        ↓
        TTS
        ↓
    Dubbed Audio
    """

    text: str

    language: str

    voice: str

    output_path: Path


@dataclass(slots=True)
class VideoDubbingResult:
    """
    Dubbing result.
    """

    audio_file: Path

    language: str

    voice: str

    sample_rate: int

    duration: float | None = None