"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : transcript_pipeline.py
Purpose     : AI Transcript Pipeline

Description
-----------
Generates a transcript from an audio file.

Pipeline
--------
Audio
  ↓
ASR
  ↓
Transcript

The Backend team is responsible for providing the audio file.

This pipeline does NOT:
• Translate text
• Extract audio
• Process video
• Run FFmpeg
• Generate subtitles
• Generate TTS audio
• Merge media

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from __future__ import annotations

from pathlib import Path

from ai.asr.models import ASRRequest
from ai.core.service_registry import ServiceRegistry

from ai.pipeline.contracts import (
    VideoTranscriptRequest,
    VideoTranscriptResult,
)


class TranscriptPipeline:
    """
    AI transcript pipeline.

    Flow
    ----
    Audio
        ↓
    ASR
        ↓
    Transcript
    """

    def __init__(self) -> None:

        self._asr_service = (
            ServiceRegistry.asr_service()
        )

    # ------------------------------------------------------------------
    # Execute
    # ------------------------------------------------------------------

    def execute(
        self,
        request: VideoTranscriptRequest,
    ) -> VideoTranscriptResult:
        """
        Generate transcript from audio.
        """

        audio_path = Path(
            request.audio_path
        )

        # --------------------------------------------------------------
        # Validate audio
        # --------------------------------------------------------------

        if not audio_path.exists():

            raise FileNotFoundError(
                f"Audio file not found: {audio_path}"
            )

        if not audio_path.is_file():

            raise ValueError(
                f"Audio path is not a file: {audio_path}"
            )

        # --------------------------------------------------------------
        # ASR
        # --------------------------------------------------------------

        asr_request = ASRRequest(
            audio_path=str(audio_path),
        )

        transcription = (
            self._asr_service.transcribe(
                asr_request
            )
        )

        # --------------------------------------------------------------
        # Result
        # --------------------------------------------------------------

        return VideoTranscriptResult(
            transcription=transcription,
        )

    # ------------------------------------------------------------------
    # Health Check
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """
        Check transcript pipeline health.
        """

        return self._asr_service.health_check()