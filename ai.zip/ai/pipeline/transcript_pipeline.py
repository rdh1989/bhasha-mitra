"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : transcript_pipeline.py
Purpose     : Video Transcript Pipeline

Description
-----------
Extract transcript from a video.

Pipeline
--------
Video
    ↓
Audio Extraction
    ↓
Speech Recognition
    ↓
Transcript

Responsibilities
----------------
• Extract audio from video
• Generate transcript
• Return transcript result

Notes
-----
This pipeline orchestrates AI services only.

It does NOT

• Load AI models
• Select providers
• Perform inference

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from __future__ import annotations

from ai.asr.service import ASRService

from ai.pipeline.contracts import (
    VideoTranscriptRequest,
    VideoTranscriptResult,
)


class TranscriptPipeline:
    """
    Video transcript generation pipeline.
    """

    def __init__(
        self,
        asr_service: ASRService,
    ) -> None:

        self._asr = asr_service

    # ------------------------------------------------------------------
    # Execute
    # ------------------------------------------------------------------

    def execute(
        self,
        request: VideoTranscriptRequest,
    ) -> VideoTranscriptResult:
        """
        Generate transcript from video.

        Workflow
        --------
        Video
            ↓
        Validate Video
            ↓
        Extract Audio
            ↓
        Speech Recognition
            ↓
        Transcript
        """

        from ai.pipeline.video_processor import VideoProcessor
        from ai.asr.models import ASRRequest

        processor = VideoProcessor()

        # --------------------------------------------------------------
        # Validate video
        # --------------------------------------------------------------

        processor.validate(request.video_path)

        # --------------------------------------------------------------
        # Extract audio
        # --------------------------------------------------------------

        audio_path = processor.extract_audio(
            request.video_path
        )

        # --------------------------------------------------------------
        # Speech Recognition
        # --------------------------------------------------------------

        asr_request = ASRRequest(
            audio_path=audio_path,
            language=request.language,
        )

        transcript = self._asr.transcribe(
            asr_request
        )

        # --------------------------------------------------------------
        # Cleanup
        # --------------------------------------------------------------

        processor.cleanup(audio_path)

        return VideoTranscriptResult(
            transcript=transcript.text,
            language=transcript.language,
            segments=transcript.segments,
        )