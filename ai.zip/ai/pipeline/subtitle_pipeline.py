"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : subtitle_pipeline.py
Purpose     : Video Subtitle Pipeline

Description
-----------
Generate subtitles from a video.

Pipeline
--------
Video
    ↓
Audio Extraction
    ↓
Speech Recognition
    ↓
Subtitle Generation
    ↓
Return Subtitle File

Responsibilities
----------------
• Extract audio from video
• Generate transcript
• Generate subtitle file
• Return subtitle result

Notes
-----
This pipeline orchestrates AI services only.

It does NOT

• Load AI models
• Select providers
• Perform inference

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from __future__ import annotations

from ai.asr.service import ASRService
from ai.subtitle.service import SubtitleService

from ai.pipeline.contracts import (
    VideoSubtitleRequest,
    VideoSubtitleResult,
)


class SubtitlePipeline:
    """
    Video subtitle generation pipeline.
    """

    def __init__(
        self,
        asr_service: ASRService,
        subtitle_service: SubtitleService,
    ) -> None:

        self._asr = asr_service
        self._subtitle = subtitle_service

    # ------------------------------------------------------------------
    # Execute
    # ------------------------------------------------------------------

    def execute(
        self,
        request: VideoSubtitleRequest,
    ) -> VideoSubtitleResult:
        """
        Generate subtitle file from video.
        """

        raise NotImplementedError(
            "Subtitle pipeline not implemented."
        )