"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : dubbing_pipeline.py
Purpose     : AI Dubbing Pipeline

Description
-----------
Generates dubbed audio from already translated text.

Pipeline
--------
Translated Text
      ↓
     TTS
      ↓
 Dubbed Audio

The Backend team is responsible for:
    • Video handling
    • Audio extraction
    • ASR
    • Translation

The AI Dubbing Pipeline is responsible only for:
    • Text-to-Speech generation

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from __future__ import annotations

from pathlib import Path

from ai.tts.models import SpeechRequest
from ai.tts.service import TTSService

from ai.pipeline.contracts import (
    VideoDubbingRequest,
    VideoDubbingResult,
)


class DubbingPipeline:
    """
    AI dubbing pipeline.

    Flow
    ----
    Translated Text
        ↓
    TTS Service
        ↓
    Dubbed Audio
    """

    def __init__(
        self,
        tts_service: TTSService,
    ) -> None:

        self._tts_service = tts_service

    # ------------------------------------------------------------------
    # Execute
    # ------------------------------------------------------------------

    def execute(
        self,
        request: VideoDubbingRequest,
    ) -> VideoDubbingResult:
        """
        Generate dubbed audio from translated text.
        """

        # --------------------------------------------------------------
        # Validate text
        # --------------------------------------------------------------

        if not request.text.strip():

            raise ValueError(
                "Text cannot be empty."
            )

        # --------------------------------------------------------------
        # Validate output path
        # --------------------------------------------------------------

        output_path = Path(
            request.output_path
        )

        output_path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        # --------------------------------------------------------------
        # TTS
        # --------------------------------------------------------------

        speech_request = SpeechRequest(
            text=request.text,
            language=request.language,
            voice=request.voice,
            output_path=output_path,
        )

        speech_result = (
            self._tts_service.synthesize(
                speech_request
            )
        )

        # --------------------------------------------------------------
        # Result
        # --------------------------------------------------------------

        return VideoDubbingResult(
            audio_file=speech_result.audio_path,
            language=speech_result.language,
            voice=speech_result.voice,
            sample_rate=speech_result.sample_rate,
            duration=speech_result.duration,
        )

    # ------------------------------------------------------------------
    # Health Check
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """
        Check TTS dependency health.
        """

        return self._tts_service.health_check()