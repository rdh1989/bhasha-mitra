"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : service_registry.py
Purpose     : AI Service Registry

Description
-----------
Constructs framework services with all required dependencies.

Responsibilities
----------------
• Resolve configured providers
• Create adapters
• Build AI services
• Return ready-to-use service instances

Notes
-----
This class acts as the dependency injection container for the AI Framework.

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from ai.translation.service import TranslationService
from ai.translation.adapter import TranslationAdapter

from ai.asr.service import ASRService
from ai.asr.adapter import ASRAdapter

from ai.language_detection.service import LanguageDetectionService
from ai.language_detection.adapter import LanguageDetectionAdapter

from ai.tts.service import TTSService
from ai.tts.adapter import TTSAdapter

from ai.subtitle.service import SubtitleService
from ai.subtitle.adapter import SubtitleAdapter

from ai.core.provider_registry import ProviderRegistry


class ServiceRegistry:
    """
    Builds framework services.
    """

    # -------------------------------------------------------------------------
    # Translation
    # -------------------------------------------------------------------------

    @staticmethod
    def translation_service() -> TranslationService:

        provider = ProviderRegistry.translation_provider()

        adapter = TranslationAdapter()

        return TranslationService(
            provider=provider,
            adapter=adapter,
        )

    # -------------------------------------------------------------------------
    # ASR
    # -------------------------------------------------------------------------

    @staticmethod
    def asr_service() -> ASRService:

        provider = ProviderRegistry.asr_provider()

        adapter = ASRAdapter()

        return ASRService(
            provider=provider,
            adapter=adapter,
        )

    # -------------------------------------------------------------------------
    # Language Detection
    # -------------------------------------------------------------------------

    @staticmethod
    def language_detection_service() -> LanguageDetectionService:

        provider = ProviderRegistry.language_detection_provider()

        adapter = LanguageDetectionAdapter()

        return LanguageDetectionService(
            provider=provider,
            adapter=adapter,
        )

    # -------------------------------------------------------------------------
    # TTS
    # -------------------------------------------------------------------------

    @staticmethod
    def tts_service() -> TTSService:

        provider = ProviderRegistry.tts_provider()

        adapter = TTSAdapter()

        return TTSService(
            provider=provider,
            adapter=adapter,
        )

    # -------------------------------------------------------------------------
    # Subtitle
    # -------------------------------------------------------------------------

    @staticmethod
    def subtitle_service() -> SubtitleService:

        adapter = SubtitleAdapter()

        return SubtitleService(
            adapter=adapter,
        )