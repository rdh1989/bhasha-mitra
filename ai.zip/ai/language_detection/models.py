"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : models.py
Purpose     : Language Detection Framework Data Models

Description:
    Defines provider-independent request and response models used by the
    Language Detection module.

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ============================================================================
# Request Models
# ============================================================================

@dataclass(slots=True)
class LanguageDetectionRequest:
    """
    Language detection request.

    The input may be plain text or an ASR transcript.
    """

    text: str


# ============================================================================
# Response Models
# ============================================================================

@dataclass(slots=True)
class DetectedLanguage:
    """
    Represents one detected language.
    """

    language: str

    confidence: float


@dataclass(slots=True)
class LanguageDetectionResult:
    """
    Standard language detection result returned by every provider.
    """

    primary_language: str

    confidence: float

    detected_languages: list[DetectedLanguage] = field(default_factory=list)