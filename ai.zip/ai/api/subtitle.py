"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : subtitle.py
Purpose     : Subtitle Generation API

Description
-----------
REST endpoints for subtitle generation.

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.subtitle.models import (
    SubtitleRequest,
)

from ai.core.service_registry import ServiceRegistry


router = APIRouter()


# -------------------------------------------------------------------------
# Service
# -------------------------------------------------------------------------

service = ServiceRegistry.subtitle_service()


# -------------------------------------------------------------------------
# AI-009
# -------------------------------------------------------------------------

@router.post(
    "/subtitle",
    summary="Generate Subtitle",
)
def generate_subtitle(
    request: SubtitleRequest,
):
    """
    Generate subtitle file.
    """

    try:

        return service.generate(request)

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )