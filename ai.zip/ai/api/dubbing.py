"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : dubbing.py
Purpose     : AI Dubbing API

Description
-----------
Generates dubbed audio from already translated text.

Flow
----
Translated Text
      ↓
DubbingPipeline
      ↓
TTS
      ↓
Dubbed Audio

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.core.pipeline_registry import PipelineRegistry

from ai.pipeline.contracts import (
    VideoDubbingRequest,
)


router = APIRouter()


# -------------------------------------------------------------------------
# Pipeline
# -------------------------------------------------------------------------

pipeline = PipelineRegistry.dubbing_pipeline()


# -------------------------------------------------------------------------
# AI Dubbing
# -------------------------------------------------------------------------

@router.post(
    "/dubbing",
    summary="Generate Dubbed Audio",
)
def generate_dubbing(
    request: VideoDubbingRequest,
):
    """
    Generate dubbed audio from translated text.
    """

    try:

        return pipeline.execute(
            request
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )