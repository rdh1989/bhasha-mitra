"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : transcript.py
Purpose     : AI Transcript Pipeline API

Description
-----------
Runs the AI transcript pipeline:

    Audio
      ↓
    ASR
      ↓
    Transcript

The Backend team provides the audio file.

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.core.pipeline_registry import PipelineRegistry

from ai.pipeline.contracts import (
    VideoTranscriptRequest,
)

router = APIRouter()


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

pipeline = PipelineRegistry.transcript_pipeline()


# ---------------------------------------------------------------------------
# AI Transcript Pipeline
# ---------------------------------------------------------------------------

@router.post(
    "/transcript",
    summary="Generate Transcript",
)
def generate_transcript(
    request: VideoTranscriptRequest,
):
    """
    Execute ASR and generate transcript only.
    """

    try:

        return pipeline.execute(
            request
        )

    except FileNotFoundError as exc:

        raise HTTPException(
            status_code=404,
            detail=str(exc),
        )

    except ValueError as exc:

        raise HTTPException(
            status_code=400,
            detail=str(exc),
        )

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )