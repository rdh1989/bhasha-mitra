"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : tts.py
Purpose     : Text-to-Speech API

Description
-----------
REST endpoints for Text-to-Speech.

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.tts.service import TTSService
from ai.tts.models import (
    TTSRequest,
    TTSResult,
)

router = APIRouter()


# --------------------------------------------------------------------------
# Service
# --------------------------------------------------------------------------

service = TTSService()


# --------------------------------------------------------------------------
# AI-008
# --------------------------------------------------------------------------

@router.post(
    "/tts",
    response_model=TTSResult,
    summary="Text To Speech",
)
def text_to_speech(
    request: TTSRequest,
):
    """
    Convert text into speech.
    """

    try:

        result = service.synthesize(request)

        return result

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )