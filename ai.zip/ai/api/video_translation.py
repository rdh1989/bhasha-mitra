"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : video_translation.py
Purpose     : Video Translation API

Description
-----------
REST APIs for the Video Translation Pipeline.

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.asr.service import ASRService
from ai.language_detection.service import LanguageDetectionService
from ai.subtitle.service import SubtitleService
from ai.translation.service import TranslationService
from ai.tts.service import TTSService

from ai.pipeline.video_translation_pipeline import (
    VideoTranslationPipeline,
)

from ai.pipeline.contracts import (
    VideoTranslationRequest,
    VideoTranslationResult,
    VideoTranscriptRequest,
    VideoTranscriptResult,
    VideoSubtitleRequest,
    VideoSubtitleResult,
    VideoDubbingRequest,
    VideoDubbingResult,
)

router = APIRouter(
    prefix="/video",
    tags=["Video Translation"],
)

# -----------------------------------------------------------------------------
# Pipeline
# -----------------------------------------------------------------------------

pipeline = VideoTranslationPipeline(
    asr_service=ASRService(),
    translation_service=TranslationService(),
    language_detection_service=LanguageDetectionService(),
    subtitle_service=SubtitleService(),
    tts_service=TTSService(),
)

# -----------------------------------------------------------------------------
# AI-010
# -----------------------------------------------------------------------------

@router.post(
    "/translate",
    response_model=VideoTranslationResult,
    summary="Translate Video",
)
def translate_video(
    request: VideoTranslationRequest,
):
    """
    Translate an entire video.
    """

    try:

        return pipeline.translate_video(request)

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )


# -----------------------------------------------------------------------------
# AI-011
# -----------------------------------------------------------------------------

@router.post(
    "/transcript",
    response_model=VideoTranscriptResult,
    summary="Generate Transcript",
)
def generate_transcript(
    request: VideoTranscriptRequest,
):
    """
    Generate transcript from video.
    """

    try:

        return pipeline.generate_transcript(request)

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )


# -----------------------------------------------------------------------------
# AI-012
# -----------------------------------------------------------------------------

@router.post(
    "/subtitles",
    response_model=VideoSubtitleResult,
    summary="Generate Subtitles",
)
def generate_subtitles(
    request: VideoSubtitleRequest,
):
    """
    Generate subtitles from video.
    """

    try:

        return pipeline.generate_subtitles(request)

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )


# -----------------------------------------------------------------------------
# AI-013
# -----------------------------------------------------------------------------

@router.post(
    "/dub",
    response_model=VideoDubbingResult,
    summary="Generate Dubbed Audio",
)
def generate_dub(
    request: VideoDubbingRequest,
):
    """
    Generate dubbed audio.
    """

    try:

        return pipeline.generate_dub(request)

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )