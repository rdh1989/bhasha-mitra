"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : asr.py
Purpose     : Speech Recognition API

Description
-----------
REST endpoints for Automatic Speech Recognition (ASR).

Author
------
Bhasha Mitra AI Team

Version
-------
1.0
===============================================================================
"""

from fastapi import APIRouter, HTTPException

from ai.asr.service import ASRService
from ai.asr.models import (
    ASRRequest,
    ASRResult,
)

router = APIRouter()

# --------------------------------------------------------------------------
# Service
# --------------------------------------------------------------------------

service = ASRService()


# --------------------------------------------------------------------------
# AI-005
# --------------------------------------------------------------------------

@router.post(
    "/asr",
    response_model=ASRResult,
    summary="Speech Recognition",
)
def speech_to_text(
    request: ASRRequest,
):
    """
    Convert speech into text.
    """

    try:

        result = service.transcribe(request)

        return result

    except Exception as exc:

        raise HTTPException(
            status_code=500,
            detail=str(exc),
        )