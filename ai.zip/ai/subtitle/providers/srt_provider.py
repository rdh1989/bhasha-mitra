"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : srt_provider.py
Purpose     : SRT Subtitle Provider

Description:
    Generates SRT subtitle files.

Design Pattern:
    Strategy

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from pathlib import Path

from ai.base.subtitle_provider import SubtitleProvider

from ai.subtitle.models import (
    SubtitleRequest,
    SubtitleResult,
)

from ai.subtitle.utils import seconds_to_srt_time


class SRTProvider(SubtitleProvider):
    """
    SRT subtitle provider.
    """

    def initialize(
        self,
    ) -> None:
        """
        Initialize provider.
        """

        pass

    def shutdown(
        self,
    ) -> None:
        """
        Shutdown provider.
        """

        pass

    def health_check(
        self,
    ) -> bool:
        """
        Provider health.
        """

        return True

    def supported_formats(
        self,
    ) -> list[str]:
        """
        Supported subtitle formats.
        """

        return ["srt"]

    def generate(
        self,
        request: SubtitleRequest,
    ) -> SubtitleResult:
        """
        Generate SRT subtitle file.
        """

        output_file = Path(request.output_path)

        #
        # Ensure .srt extension
        #
        if output_file.suffix.lower() != ".srt":

            output_file = output_file.with_suffix(".srt")

        #
        # Create directory
        #
        output_file.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        with open(
            output_file,
            "w",
            encoding="utf-8",
        ) as fp:

            for index, segment in enumerate(
                request.transcription.segments,
                start=1,
            ):

                fp.write(f"{index}\n")

                fp.write(
                    f"{seconds_to_srt_time(segment.start)}"
                    f" --> "
                    f"{seconds_to_srt_time(segment.end)}\n"
                )

                fp.write(
                    f"{segment.text.strip()}\n\n"
                )

        return SubtitleResult(
            subtitle_path=output_file,
            subtitle_format="srt",
            segment_count=len(
                request.transcription.segments
            ),
        )