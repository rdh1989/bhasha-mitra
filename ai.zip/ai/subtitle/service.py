"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : service.py
Purpose     : Subtitle Generation Service

Description:
    Generates subtitle files using the configured subtitle provider.

Design Patterns:
    • Strategy
    • Dependency Injection

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from ai.base.subtitle_provider import SubtitleProvider
from ai.subtitle.models import (
    SubtitleRequest,
    SubtitleResult,
)


class SubtitleService:
    """
    Subtitle orchestration service.
    """

    def __init__(
        self,
        provider: SubtitleProvider,
    ) -> None:

        self._provider = provider

    def generate(
        self,
        request: SubtitleRequest,
    ) -> SubtitleResult:
        """
        Generate subtitle file.
        """

        return self._provider.generate(request)

    def health_check(
        self,
    ) -> bool:
        """
        Verify provider health.
        """

        return self._provider.health_check()