"""
===============================================================================
Bhasha Mitra - AI Framework
-------------------------------------------------------------------------------
Module      : models.py
Purpose     : ASR Framework Data Models

Description:
    Defines framework data models used by the ASR module.

These models are provider independent.

Author:
    Bhasha Mitra AI Team

Version:
    1.0
===============================================================================
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ============================================================================
# Request Models
# ============================================================================

@dataclass(slots=True)
class TranscriptionRequest:
    """
    Speech-to-text request.
    """

    audio_path: str

    language: str | None = None

    translate: bool = False


# ============================================================================
# Response Models
# ============================================================================

@dataclass(slots=True)
class Segment:
    """
    Represents one spoken segment.
    """

    id: int

    start: float

    end: float

    text: str

    confidence: float | None = None


@dataclass(slots=True)
class LanguageInfo:
    """
    Language detection information.
    """

    language: str

    probability: float


@dataclass(slots=True)
class TranscriptionResult:
    """
    Standard transcription result returned by every ASR provider.
    """

    text: str

    language: LanguageInfo

    duration: float

    segments: list[Segment] = field(default_factory=list)