"""Configured subtitle formatter implementations."""
