/******************************************************************************
 * Bhasha Mitra - Upload page controller
 *****************************************************************************/

class UploadController {
    constructor() {
        this.form = document.getElementById("uploadForm");
        this.fileInput = document.getElementById("videoFile");
        this.dropZone = document.getElementById("dropZone");
        this.startButton = document.getElementById("startTranslation");
        this.removeButton = document.getElementById("removeFile");
        this.selectedFilePanel = document.getElementById("selectedFile");
        this.selectedFileName = document.getElementById("selectedFileName");
        this.selectedFileMeta = document.getElementById("selectedFileMeta");
        this.preview = document.getElementById("videoPreview");
        this.previewVideo = this.preview?.querySelector("video");
        this.sourceLanguage = document.getElementById("sourceLanguage");
        this.message = document.getElementById("formMessage");
        this.progressContainer = document.getElementById("uploadProgress");
        this.progressBar = document.getElementById("progressBar");
        this.progressText = document.getElementById("progressText");
        this.progressLabel = document.getElementById("progressLabel");
        this.selectedFile = null;
        this.previewUrl = null;

        this.initialize();
    }

    initialize() {
        this.fileInput?.addEventListener("change", (event) => {
            const [file] = event.target.files;
            if (file) this.handleFile(file);
        });

        ["dragenter", "dragover"].forEach((eventName) => {
            this.dropZone?.addEventListener(eventName, (event) => {
                event.preventDefault();
                this.dropZone.classList.add("drag-active");
            });
        });

        ["dragleave", "drop"].forEach((eventName) => {
            this.dropZone?.addEventListener(eventName, (event) => {
                event.preventDefault();
                this.dropZone.classList.remove("drag-active");
            });
        });

        this.dropZone?.addEventListener("drop", (event) => {
            const [file] = event.dataTransfer.files;
            if (file) this.handleFile(file);
        });

        this.removeButton?.addEventListener("click", () => this.clearFile());
        this.form?.addEventListener("submit", (event) => this.startTranslation(event));
    }

    handleFile(file) {
        if (!this.validateFile(file)) return;

        this.selectedFile = file;
        this.selectedFileName.textContent = file.name;
        this.selectedFileMeta.textContent = `${this.formatFileSize(file.size)} · Ready for translation`;
        this.selectedFilePanel.hidden = false;
        this.startButton.disabled = false;
        this.setMessage("Video selected. Choose your settings and start translation.", "success");

        if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
        this.previewUrl = URL.createObjectURL(file);
        if (this.previewVideo) {
            this.previewVideo.src = this.previewUrl;
            this.preview.hidden = false;
        }
    }

    clearFile() {
        this.selectedFile = null;
        this.fileInput.value = "";
        this.selectedFilePanel.hidden = true;
        this.startButton.disabled = true;
        this.preview.hidden = true;
        if (this.previewVideo) this.previewVideo.removeAttribute("src");
        if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
        this.previewUrl = null;
        this.setMessage("Select a video to continue.");
    }

    validateFile(file) {
        const validExtensions = ["mp4", "mov", "avi", "mkv", "webm"];
        const extension = file.name.split(".").pop().toLowerCase();
        const maxSize = 2 * 1024 * 1024 * 1024;

        if (!validExtensions.includes(extension)) {
            this.setMessage("Choose an MP4, MOV, AVI, MKV, or WEBM video.", "error");
            return false;
        }
        if (file.size > maxSize) {
            this.setMessage("The video must be 2 GB or smaller.", "error");
            return false;
        }
        return true;
    }

    async startTranslation(event) {
        event.preventDefault();
        if (!this.selectedFile) {
            this.setMessage("Select a video before starting translation.", "error");
            return;
        }

        this.startButton.disabled = true;
        this.progressContainer.hidden = false;
        this.progressLabel.textContent = "Uploading your video";
        this.updateProgress(0);
        this.setMessage("Uploading your video.");

        try {
            const formData = new FormData();
            formData.append("file", this.selectedFile);
            const upload = await Api.upload("/api/v1/upload", formData);

            this.progressLabel.textContent = "Detecting original language";
            this.updateProgress(65);
            this.setMessage("Video uploaded. Detecting the original language.");

            const detection = await Api.post(
                `/api/v1/upload/${encodeURIComponent(upload.filename)}/detect-language`
            );

            this.updateProgress(100);
            this.applyDetectedLanguage(detection);
            this.setMessage(
                `Video uploaded. Original language detected as ${detection.language_name}.`,
                "success"
            );
        } catch (error) {
            const message = error.message || "The video was uploaded, but language detection failed.";
            this.setMessage(message, "error");
        } finally {
            this.startButton.disabled = false;
        }
    }

    updateProgress(value) {
        this.progressBar.style.width = `${value}%`;
        this.progressText.textContent = `${value}%`;
        this.progressBar.parentElement.setAttribute("aria-valuenow", value);
    }

    applyDetectedLanguage(detection) {
        const matchingOption = this.sourceLanguage?.querySelector(
            `option[value="${CSS.escape(detection.language)}"]`
        );

        if (matchingOption) {
            this.sourceLanguage.value = detection.language;
        }
    }

    setMessage(message, type = "") {
        this.message.textContent = message;
        this.message.className = `form-message${type ? ` is-${type}` : ""}`;
    }

    formatFileSize(bytes) {
        if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    window.Upload = new UploadController();
});
