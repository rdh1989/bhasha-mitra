"""
===============================================================================
Bhasha Mitra
Frontend Routes

Description:
    Frontend page routing using FastAPI + Jinja2

Author  : Team 4
Version : 1.0.0
===============================================================================
"""

from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

# =============================================================================
# Templates
# =============================================================================

BASE_DIR = Path(__file__).resolve().parent.parent

templates = Jinja2Templates(
    directory=str(BASE_DIR / "templates")
)

# =============================================================================
# Router
# =============================================================================

router = APIRouter(
    tags=["Frontend"]
)

# =============================================================================
# Helper Functions
# =============================================================================


def template_context(request: Request, **kwargs):
    """
    Common template context.
    """

    context = {
        "request": request,
        "app_name": "Bhasha Mitra",
        "current_year": datetime.now().year,
    }

    context.update(kwargs)

    return context


def render_dashboard(request: Request):
    """
    Common dashboard renderer.
    """

    return templates.TemplateResponse(
        request=request,
        name="dashboard.html",
        context=template_context(
            request,
            page="dashboard",
            dashboard={
                "total_videos": 25,
                "completed": 22,
                "processing": 2,
                "failed": 1,
            },
        ),
    )


# =============================================================================
# Home
# =============================================================================

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """
    Default application page.
    """

    return render_dashboard(request)


# =============================================================================
# Dashboard
# =============================================================================

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):

    return render_dashboard(request)


# =============================================================================
# Upload
# =============================================================================

@router.get("/upload", response_class=HTMLResponse)
async def upload(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="upload.html",
        context=template_context(
            request,
            page="upload",
        ),
    )


# =============================================================================
# Translation
# =============================================================================

@router.get("/translation", response_class=HTMLResponse)
async def translation(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="translation.html",
        context=template_context(
            request,
            page="translation",
            job_id="BM-20260724-0001",
            source_language="English",
            target_language="Marathi",
            duration="04:36",
        ),
    )


# =============================================================================
# History
# =============================================================================

@router.get("/history", response_class=HTMLResponse)
async def history(request: Request):

    history_data = [
        {
            "filename": "Training.mp4",
            "size": "120 MB",
            "source_language": "English",
            "target_language": "Marathi",
            "duration": "04:36",
            "status": "Completed",
            "created_at": "24 Jul 2026",
        },
        {
            "filename": "Demo.mp4",
            "size": "86 MB",
            "source_language": "English",
            "target_language": "Hindi",
            "duration": "03:12",
            "status": "Running",
            "created_at": "23 Jul 2026",
        },
        {
            "filename": "Lecture.mp4",
            "size": "540 MB",
            "source_language": "English",
            "target_language": "Tamil",
            "duration": "21:40",
            "status": "Failed",
            "created_at": "20 Jul 2026",
        },
    ]

    return templates.TemplateResponse(
        request=request,
        name="history.html",
        context=template_context(
            request,
            page="history",
            history=history_data,
        ),
    )


# =============================================================================
# Login
# =============================================================================

@router.get("/login", response_class=HTMLResponse)
async def login(request: Request):

    return templates.TemplateResponse(
        request=request,
        name="login.html",
        context=template_context(
            request,
            page="login",
        ),
    )


# =============================================================================
# Login Submit (Demo)
# =============================================================================

@router.post("/login", response_class=HTMLResponse)
async def login_submit(request: Request):

    return render_dashboard(request)